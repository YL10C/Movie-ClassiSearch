import json

# Path to your JSONL file
jsonl_file = "1956/output.jsonl"
count = 0
# Open and read the JSONL file
with open(jsonl_file, "r", encoding="utf-8") as file:
    for line in file:
        # Parse each line as a JSON object
        record = json.loads(line.strip())
        count += 1
        print(record)  # Print the JSON object

print(count)