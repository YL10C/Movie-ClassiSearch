import json

# File paths
jsonl_file = "1956/output.jsonl"
json_output_file = "output.json"

# Read JSONL and write to JSON
with open(jsonl_file, "r", encoding="utf-8") as file:
    records = [json.loads(line) for line in file]

with open(json_output_file, "w", encoding="utf-8") as json_file:
    json.dump(records, json_file, ensure_ascii=False, indent=4)

print(f"Processed {len(records)} records and saved to {json_output_file}")
